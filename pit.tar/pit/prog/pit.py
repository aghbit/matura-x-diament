if __name__ == "__main__":
    a = int(input())
    b = int(input())
    print(a**2+b**2,end="")