if __name__ == "__main__":
    a,b = int(input().split(" "))
    print(a**2+b**2,end="")