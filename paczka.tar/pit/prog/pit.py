if __name__ == "__main__":
    a,b = input().split(" ")
    a,b = int(a), int(b)
    print(a**2+b**2)